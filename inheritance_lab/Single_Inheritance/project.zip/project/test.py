from project.dog import Dog

obj = Dog()
print(obj.eat())
print(obj.bark())
