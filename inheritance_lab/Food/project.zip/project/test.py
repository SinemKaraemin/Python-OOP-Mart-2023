from project.fruit import Fruit

obj = Fruit('Banana', '05.03.2023')
print(obj.name)
print(obj.expiration_date)
