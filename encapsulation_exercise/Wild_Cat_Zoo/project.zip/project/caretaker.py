from .worker import Worker


class Caretaker(Worker):
    pass
