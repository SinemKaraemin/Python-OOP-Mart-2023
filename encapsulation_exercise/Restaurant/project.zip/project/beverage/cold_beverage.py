from .beverage.beverage import Beverage


class ColdBeverage(Beverage):
    pass
