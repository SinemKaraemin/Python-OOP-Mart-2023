from .vehicle import Vehicle


class Motorcycle(Vehicle):
    pass
